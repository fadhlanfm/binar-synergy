let jumlahRoda = 50192

switch (jumlahRoda) {
  case 1:
    console.log("sepeda roda 1")
    break;
  case 2:
    console.log("motor")
    break;
  case 3:
    console.log("bajaj")
    break
  case 4:
    console.log("mobil")
    break
  default:
    console.log("ban kebanyakan")
    break;
}