
// // falsy / truthy
// // true termasuk truthy
// // false termasuk falsy


// let number = -5;
// // console.log("number > 0: ", number > 0)
// if (number  > 0) {
//   console.log("statement di atas truthy")
// } else {
//   console.log("statement di atas falsy")
// }

// // console.log(0)
// let string = "ada isinya"
// let arr = []
// if (arr.length) {
//   console.log("truthy")
// } else {
//   console.log("falsy")
// }

// let a
// console.log("a", a)
// // falsy: 0, "", NaN, undefined, null


let jumlahRoda = 50000

if (jumlahRoda == 1){
  console.log("sepeda roda 1");
} else if (jumlahRoda == 2){
  console.log("motor");
} else if (jumlahRoda == 3){
  console.log("bajaj");
} else if (jumlahRoda == 4){
  console.log("mobil");
} else {
  console.log("ban kebanyakan");
}

