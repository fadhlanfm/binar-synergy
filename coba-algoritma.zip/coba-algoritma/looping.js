// for (let i = 0; i < 10; i++) {
//   console.log(i)
// }

// while (i < 10) {
  //   console.log(i)
  //   i++
  // }
  
let i = 0;
do {
  console.log(i)
  i++
} while(i < 10)

