console.log("fadhlan" === "fariz")
console.log("fadhlan" !== "fariz")
