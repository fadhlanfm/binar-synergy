// array manipulation

let arr = [1, 2, 3, 4, 5]
// console.log(arr)
// console.log(arr[1])
// console.log(arr.length)
// console.log(arr[6])
// console.log(arr[-6])
// console.log(arr[arr.length - 1])
// console.log(arr[0])
// arr[0] = 10
// console.log(arr)

// arr.push(6)
// console.log(arr)
// arr.unshift(0)
// console.log(arr)

// let poppedElement = arr.pop()
// console.log("poppedElement", poppedElement)
// console.log(arr)

// let shiftedElement = arr.shift()
// console.log(arr)

for (let i = 0; i < arr.length; i++) {
  // console.log(arr[i])
  console.log(i)
}

i = 0 (0 < 5)
0
i = 1

i = 1 (1 < 5)
1
i = 2

i = 2 (2 < 5)
2
i = 3

i = 3 (3 < 5)
3
i = 4

i = 4 (4 < 5)
4
i = 5

i = 5 (5 < 5)
STOP