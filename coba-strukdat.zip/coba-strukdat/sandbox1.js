// person = "fadhlan"
// var person
// console.log(person)

// person1 = "fariz"
// let person1
// console.log(person1)

var person = "fadhlan"
var person = "fadhlan1"
console.log(person)